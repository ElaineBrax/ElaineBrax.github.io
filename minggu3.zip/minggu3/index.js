const express = require("express");
const app = express();

app.use(express.urlencoded({ extended: true }));

//connect DB
const Sequelize = require("sequelize");
const conn = new Sequelize("wsinf20222m3", "root", "", {
    host: "localhost",
    dialect: "mysql",
    logging: true
});

// conn.query("select * from toko").then(function(hasil){
//     console.log(hasil);
// }).catch(function(err) {
//     console.log("ERROR!");
//     console.log(err);
// });


// conn.query("insert into kategori_buku (nama, created_at, updated_at) values('mbo', now(), now())").then(function(hasil){
//     console.log("insert");
//     // console.log(hasil);

//     const [result, metadata] = hasil;
//     console.log(result);
// }).catch(function(err) {
//     console.log("ERROR!");
//     console.log(err);
// });

// console.log("1");
// conn.query("select * from toko").then(function (hasil) {
//     console.log("2");
//     conn.query("select * from toko").then(function (hasil) {
//         console.log("3");
//         conn.query("select * from toko").then(function (hasil) {
//             console.log("4");
//         });
//         console.log("5");
//     });
//     console.log("6");
// });
// console.log("7");

// async function awok(){
//     try{
//         let [result, metadata] = await conn.query("select * from toko");
//         [result, metadata] = await conn.query("select * from toko");
//         [result, metadata] = await conn.query("select * from toko");
//     }
//     catch{
//         console.log("ERROR!");
//         console.log(err);
//     }
// }

// awok();
const port = 3000;
app.listen(port, function(){
    console.log(`listening on port ${port}`)
});
// app.post("/api/pengguna", async function(req, res){
//     const nama = req.body.nama;
//     const gender = parseInt(req.body.gender);
//     //let [result, metadata] = await conn.query(`insert into pengguna (nama, gender, created_at, updated_at) values('${nama}', '${gender}', now(), now())`);
//     let [result, metadata] = await conn.query(`insert into pengguna (nama, gender, cerated_at, updated_at) values (:nama, :gender, now(), now())`, {
//         replacement: {
//             nama: nama,
//             gender: gender
//         }
//     })
//     const id = result;
//     [result, metadata] = await conn.query(`select * from pengguna where id = '${id}'`);
//     return res.status(201).send(result[0]);
// });

// const Model = Sequence.Model;
// const DataTypes = Sequelize.DataTypes;
const {Model, DataTypes} = Sequelize;
class Pengguna extends Model{}
Pengguna.init({
    id:{
        type: DataTypes.INTEGER,
        primaryKey:true,
        autoIncrement:true
    },
    nama:{
        type: DataTypes.STRING(255),
        allowNull: false
    },
    gender:{
        type:DataTypes.BOOLEAN,
        allowNull: false
    }
},{
    sequelize:conn,
    tableName:"Pengguna",
    paranoid: true
    //timestamps:false
});
app.get("/init", async function(req, res){
    //await Pengguna.sync({force:true});
    await conn.sync({force: true});
    return res.status(200).send("OK");
});
app.post("/api/pengguna", async function (req, res) {
    try {
        const nama = req.body.nama;
        const gender = parseInt(req.body.gender);

        const penggunaBaru = await Pengguna.create({ nama: nama, gender: gender });

        return res.status(201).send(penggunaBaru);
    }
    catch (err) {
        console.log(err);
        return res.status(500).send(err);
    }
});

app.get("/api/pengguna/:id", async function(req, res){
    const id = parseInt(req.params.id)
    const p = await Pengguna.findByPk(id);
    if(p){
        return res.status(200).send(p);
    }
    else{
        return res.status(404).send({"msg":"pengguna not found!"});
    }
});

// //tipe data yang mungkin sering dipakai:
// //STRING
// //STRING(50)
// //TEXT
// //DECIMAL
// //DECIMAL(5,2)
// //DATE
// //DATEONLY
// //BOOLEAN

// //opsi untuk kolom:
// //primaryKey:boolean
// //autoIncrement:boolean
// //allowNull:boolean
// //unique:boolean atau string. Kalau string dipakai untuk mengganti nama constraint unique nya. Kalau ada 2 field diberi nama constraint unique yang sama maka akan jadi composite unique
// //field:string -> mengganti nama field supaya beda dengan nama attribut
// //references:{
// //  model:Model,
// //  key:string -> nama field yang di-refer
// //}
// //defaultValue:Any
// //untuk info lebih lengkap bisa lihat dokumentasi